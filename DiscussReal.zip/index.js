const cheerio = require("cheerio");
const axios = require("axios");
const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const io = new Server(server);
const nodemailer = require('nodemailer');
var userEmail;
const myPassword = process.env['emailPassword']
var username;
var password;
var vCode = Math.floor(Math.random() * 10000) + 1;
const Database = require("@replit/database")
const db = new Database()
var logPassTotal;
var loggedIn = false;
var transporter = nodemailer.createTransport({
  service: 'outlook',
  auth: {
    user: 'logankento@outlook.com',
    pass:  myPassword
  }
});




app.get('/', (req, res) => {
  res.sendFile(__dirname + '/signup.html');

});
app.get('/login.html', (req, res) => {
  res.sendFile(__dirname + '/login.html');
  
});
app.get('/index9483098320439850937209853098230980957323.html', (req, res) => {
  res.sendFile(__dirname + '/index.html');

});
app.get('/tos.html', (req, res) => {
  res.sendFile(__dirname + '/tos.html');

});

io.on('connection', (socket) => {

  console.log('a user connected');
    socket.on('disconnect', () => {
    console.log('user disconnected');
  });
});


server.listen(3000, () => {
  console.log('listening on *:3000');
  console.log()
});
io.on('connection', (socket) => {
  socket.on('chat message', msg => {
    io.emit('chat message', msg);

  });
  socket.on('un send', usern => {
     username = usern;

  }); 
    
  
  socket.on('pass send', pass => {
       password = pass;
      
  }); 
  socket.on('loggedRequest', uknowtherules => {
     if (loggedIn == false) {
       io.emit('errorBack', 'bruh');
     }
  }) 
   socket.on('verified', rickroll => {
     console.log('server knows user is verified. un and pass are ' +username+" "+password);
    io.emit('verifiedCon', 'server knows user is verified. Un and pass are '+username+' '+password);
  db.set(username, password).then(() => {})

   }); 
    socket.on ('logpass send', logpass => {
      logPassTotal = logpass;
    })
    socket.on('logname send', logname => {
      db.get(logname).then(value => {
         if (logPassTotal == value) {
           console.log('everything is in order');
           loggedIn = true;
           io.emit('log sucsess', "it works");
           
         } else {
           console.log('wrong pass');
           io.emit('wrong unpass', 'wrong');
            
         }
      });
    });

  
  socket.on('email send', userMail => {
    
    console.log(vCode);
    console.log(userMail);
var mailOptions = {
  from: 'logankento@outlook.com',
  to: userMail,
  subject: 'Verify your email',
  text: 'Your Discuss verification code is '+vCode+". Ignore this message if you did not sign up for Discuss."
};

    transporter.sendMail(mailOptions, function(error, info){
  if (error) {
    console.log(error);
  } else {
    console.log('Email sent: ' + info.response);
  }
      io.emit('verCode', vCode);
 });
  });
});







